<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<html>
    <head>
        <?php
        wp_head();
        ?>
    </head>
    <body>
        <?php 
        wp_footer();
        ?>
    </body>
</html>
